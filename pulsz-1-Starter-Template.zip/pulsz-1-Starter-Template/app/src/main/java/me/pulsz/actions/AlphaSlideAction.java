package me.pulsz.actions;

import android.view.View;

import me.pulsz.utils.AnimationUtils;

public class AlphaSlideAction implements OnSlideAction {
    private final View view;
    private final boolean reverse;

    public AlphaSlideAction(View view, boolean reverse) {
        this.view = view;
        this.reverse = reverse;
    }

    @Override
    public void onSlide(View view, float slideOffset) {
        float alpha = AnimationUtils.normalize(slideOffset, -1.0F, 0.0F, 0.0F, 1.0F);
        this.view.setAlpha(!this.reverse ? alpha : 1.0F - alpha);
    }
}
