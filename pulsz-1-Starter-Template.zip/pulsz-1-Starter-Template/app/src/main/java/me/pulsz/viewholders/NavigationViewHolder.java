package me.pulsz.viewholders;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import me.pulsz.R;
import me.pulsz.adapters.NavigationAdapter;

public abstract class NavigationViewHolder extends RecyclerView.ViewHolder {
    public NavigationViewHolder(@NonNull View itemView) {
        super(itemView);
    }

    public static final class NavMenuItemViewHolder extends NavigationViewHolder {
        private final NavigationAdapter.NavigationAdapterListener listener;

        public NavMenuItemViewHolder(@NonNull View itemView, final NavigationAdapter.NavigationAdapterListener listener) {
            super(itemView);
            this.listener = listener;
        }
    }

    public static final class NavDividerViewHolder extends NavigationViewHolder {
        public NavDividerViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }

    public static final class TaskFolderViewHolder extends NavigationViewHolder {
        private final NavigationAdapter.NavigationAdapterListener listener;

        public TaskFolderViewHolder(@NonNull View itemView, NavigationAdapter.NavigationAdapterListener listener) {
            super(itemView);
            this.listener = listener;
        }
    }
}
