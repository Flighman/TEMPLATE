package me.pulsz.actions;

import androidx.annotation.FloatRange;

public interface OnSandwichSlideAction {
    void onSlide(@FloatRange(from = 0.0D,fromInclusive = true,to = 1.0D,toInclusive = true) float slideOffset);
}
