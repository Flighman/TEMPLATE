package me.pulsz.adapters;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckedTextView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import me.pulsz.R;
import me.pulsz.models.NavigationModelItem;
import me.pulsz.viewholders.NavigationViewHolder;

public class NavigationAdapter extends ListAdapter {
    private static final int VIEW_TYPE_NAV_MENU_ITEM = 4;
    private static final int VIEW_TYPE_NAV_DIVIDER = 6;
    private static final int VIEW_TYPE_NAV_TASK_FOLDER_ITEM = 5;

    private final NavigationAdapter.NavigationAdapterListener listener;

    public NavigationAdapter(NavigationAdapterListener listener) {
        super((DiffUtil.ItemCallback) NavigationModelItem.NavModelItemDiff.INSTANCE);
        this.listener = listener;
    }

    @Override
    public int getItemViewType(int position) {
        NavigationModelItem navigationModelItem = (NavigationModelItem) this.getItem(position);
        if(navigationModelItem instanceof NavigationModelItem.NavMenuItem){
            return VIEW_TYPE_NAV_MENU_ITEM;
        }
        else if(navigationModelItem instanceof NavigationModelItem.NavTaskFolder){
            return VIEW_TYPE_NAV_TASK_FOLDER_ITEM;
        }
        else if(navigationModelItem instanceof NavigationModelItem.NavDivider){
            return VIEW_TYPE_NAV_DIVIDER;
        }
        return 0;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        NavigationViewHolder viewHolder;
        Context context = parent.getContext();
        switch (viewType) {
            case VIEW_TYPE_NAV_MENU_ITEM:
                View menuItemView = LayoutInflater.from(context).inflate(R.layout.nav_menu_item_layout, parent, false);
                viewHolder = (NavigationViewHolder) new NavigationViewHolder.NavMenuItemViewHolder(menuItemView, listener);
                break;
            case VIEW_TYPE_NAV_TASK_FOLDER_ITEM:
                View folderTaskItemView = LayoutInflater.from(context).inflate(R.layout.nav_task_folder_item_layout, parent, false);
                viewHolder = (NavigationViewHolder) new NavigationViewHolder.TaskFolderViewHolder(folderTaskItemView, listener);
                break;
            case VIEW_TYPE_NAV_DIVIDER:
                View navDividerItem = LayoutInflater.from(context).inflate(R.layout.nav_divider_item_layout, parent, false);
                viewHolder = (NavigationViewHolder) new NavigationViewHolder.TaskFolderViewHolder(navDividerItem, listener);
                break;
            default:
                throw new RuntimeException("Unsupported view holder type");
        }
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        NavigationModelItem navigationModelItem = (NavigationModelItem) this.getItem(position);
        if(navigationModelItem instanceof NavigationModelItem.NavMenuItem){
            final NavigationModelItem.NavMenuItem naveMenuItem = (NavigationModelItem.NavMenuItem) navigationModelItem;
            CheckedTextView checkedTextView = holder.itemView.findViewById(R.id.nav_item_title);
            Drawable navMenuDrawable = holder.itemView.getContext().getResources().getDrawable(naveMenuItem.getIcon());
            checkedTextView.setCompoundDrawablesRelativeWithIntrinsicBounds(navMenuDrawable, null, null, null);
            checkedTextView.setText(naveMenuItem.getTitleRes());
            checkedTextView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.onNavMenuItemClicked(naveMenuItem);
                }
            });
        }
        else if(navigationModelItem instanceof NavigationModelItem.NavTaskFolder){
            final NavigationModelItem.NavTaskFolder navTaskFolder = (NavigationModelItem.NavTaskFolder)this.getItem(position);
            TextView textView = holder.itemView.findViewById(R.id.nav_item_title);
            textView.setText(navTaskFolder.getTaskFolder());
            textView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.onNavTaskFolderClicked(navTaskFolder);
                }
            });
        }
        else if(navigationModelItem instanceof NavigationModelItem.NavDivider){
            final NavigationModelItem.NavDivider navDivider = (NavigationModelItem.NavDivider)this.getItem(position);
            TextView textView = holder.itemView.findViewById(R.id.divider_subtitle);
            textView.setText(navDivider.getTitle());
        }
    }

    public interface NavigationAdapterListener {
        void onNavMenuItemClicked(NavigationModelItem.NavMenuItem navMenuItem);

        void onNavTaskFolderClicked(NavigationModelItem.NavTaskFolder navTaskFolder);
    }
}
