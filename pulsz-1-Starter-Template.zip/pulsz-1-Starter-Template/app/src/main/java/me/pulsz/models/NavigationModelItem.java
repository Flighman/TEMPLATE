package me.pulsz.models;

import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.annotation.StringRes;
import androidx.recyclerview.widget.DiffUtil;

import kotlin.jvm.internal.Intrinsics;

public abstract class NavigationModelItem {
    public static final class NavMenuItem extends NavigationModelItem {
        private final int id;
        private final int icon;
        private final int titleRes;
        private final Taskbox taskbox;
        private boolean checked;

        public NavMenuItem(int id, @DrawableRes int icon, @StringRes int titleRes, Taskbox taskbox, boolean checked) {
            this.id = id;
            this.icon = icon;
            this.titleRes = titleRes;
            this.taskbox = taskbox;
            this.checked = checked;
        }

        public final int getId() {
            return this.id;
        }

        public final int getIcon() {
            return this.icon;
        }

        public final int getTitleRes() {
            return this.titleRes;
        }

        public final Taskbox getTaskbox() {
            return this.taskbox;
        }

        public final boolean getChecked() {
            return this.checked;
        }

        public final void setChecked(boolean checked) {
            this.checked = checked;
        }
    }

    public static final class NavDivider extends NavigationModelItem {
        private final String title;

        public final String getTitle() {
            return this.title;
        }

        public NavDivider(String title) {
            this.title = title;
        }
    }

    public static final class NavTaskFolder extends NavigationModelItem {
        private final String taskFolder;

        public final String getTaskFolder() {
            return this.taskFolder;
        }

        public NavTaskFolder(String taskFolder) {
            this.taskFolder = taskFolder;
        }
    }

    public static final class NavModelItemDiff extends DiffUtil.ItemCallback {
        public static final NavigationModelItem.NavModelItemDiff INSTANCE;
        static {
            INSTANCE = new NavigationModelItem.NavModelItemDiff();
        }

        @Override
        public boolean areItemsTheSame(@NonNull Object oldItem, @NonNull Object newItem) {
            return oldItem instanceof NavigationModelItem.NavMenuItem && newItem instanceof NavigationModelItem.NavMenuItem ? ((NavigationModelItem.NavMenuItem)oldItem).getId() == ((NavigationModelItem.NavMenuItem)newItem).getId() : (oldItem instanceof NavigationModelItem.NavTaskFolder && newItem instanceof NavigationModelItem.NavTaskFolder ? TaskFolderDiff.INSTANCE.areItemsTheSame(((NavigationModelItem.NavTaskFolder)oldItem).getTaskFolder(), ((NavigationModelItem.NavTaskFolder)newItem).getTaskFolder()) : Intrinsics.areEqual(oldItem, newItem));
        }

        @Override
        public boolean areContentsTheSame(@NonNull Object oldItem, @NonNull Object newItem) {
            return oldItem instanceof NavigationModelItem.NavMenuItem && newItem instanceof NavigationModelItem.NavMenuItem ? ((NavigationModelItem.NavMenuItem)oldItem).getIcon() == ((NavigationModelItem.NavMenuItem)newItem).getIcon() && ((NavigationModelItem.NavMenuItem)oldItem).getTitleRes() == ((NavigationModelItem.NavMenuItem)newItem).getTitleRes() && ((NavigationModelItem.NavMenuItem)oldItem).getChecked() == ((NavigationModelItem.NavMenuItem)newItem).getChecked() : (oldItem instanceof NavigationModelItem.NavTaskFolder && newItem instanceof NavigationModelItem.NavTaskFolder ? TaskFolderDiff.INSTANCE.areContentsTheSame(((NavigationModelItem.NavTaskFolder)oldItem).getTaskFolder(), ((NavigationModelItem.NavTaskFolder)newItem).getTaskFolder()) : false);
        }
    }
}
