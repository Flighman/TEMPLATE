package me.pulsz.fragments;

import android.content.Context;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.shape.MaterialShapeDrawable;

import java.util.ArrayList;

import me.pulsz.R;
import me.pulsz.actions.AlphaSlideAction;
import me.pulsz.actions.ForegroundSheetTransformSlideAction;
import me.pulsz.actions.ScrollToTopStateAction;
import me.pulsz.actions.VisibilityStateAction;
import me.pulsz.adapters.NavigationAdapter;
import me.pulsz.models.NavigationModelItem;
import me.pulsz.utils.SemiCircleEdgeCutoutTreatment;
import me.pulsz.viewmodels.NavigationViewModel;

public class BottomNavDrawerFragment extends Fragment implements NavigationAdapter.NavigationAdapterListener {
    @Override
    public void onNavMenuItemClicked(NavigationModelItem.NavMenuItem navMenuItem) {
        Toast.makeText(getContext(), "Nav Item Clicked", Toast.LENGTH_LONG).show();
    }

    @Override
    public void onNavTaskFolderClicked(NavigationModelItem.NavTaskFolder navTaskFolder) {
        Toast.makeText(getContext(), "Nav Folder Clicked", Toast.LENGTH_LONG).show();
    }

    public static enum SandwichState {
        CLOSED,
        OPEN,
        SETTLING;
    }

    private FrameLayout backgroundContainer;
    private LinearLayout foregroundContainer;
    private ImageView profileImageView;
    private View scrimView;
    private BottomSheetBehavior<FrameLayout> behavior;
    private BottomNavDrawerFragment.SandwichState sandwichState;
    private RecyclerView navRecyclerView;
    private OnBackPressedCallback onBackPressedCallback;
    private NavigationViewModel navigationViewModel;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final FragmentActivity fragmentActivity = requireActivity();
        onBackPressedCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if(behavior.getState() == BottomSheetBehavior.STATE_EXPANDED){
                    open();
                }
                else if(behavior.getState() == BottomSheetBehavior.STATE_HALF_EXPANDED) {
                    close();
                }
            }
        };
        fragmentActivity.getOnBackPressedDispatcher().addCallback(this,onBackPressedCallback);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View inflateView = inflater.inflate(R.layout.fragment_bottom_nav_drawer, container, false);
        backgroundContainer = inflateView.findViewById(R.id.background_container);
        backgroundContainer.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
                view.setTag(R.id.tag_system_window_inset_top, windowInsets.getSystemWindowInsetTop());
                return windowInsets;
            }
        });
        return inflateView.getRootView();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        // Find Views Here
        foregroundContainer = view.findViewById(R.id.foreground_container);
        profileImageView = view.findViewById(R.id.profile_image_view);
        scrimView = view.findViewById(R.id.scrim_view);
        behavior = BottomSheetBehavior.from(backgroundContainer);
        navRecyclerView = view.findViewById(R.id.nav_recycler_view);
        navigationViewModel = new ViewModelProvider(getActivity()).get(NavigationViewModel.class);

        backgroundContainer.setBackground(getBackgroundShapeDrawable());
        foregroundContainer.setBackground(getForegroundShapeDrawable());
        Glide.with(this)
                .load(R.drawable.avatar_2)
                .circleCrop()
                .into(profileImageView);
        final VisibilityStateAction scrimViewVisibilityStateAction = new VisibilityStateAction(scrimView, false);
        final ScrollToTopStateAction scrollToTopStateAction = new ScrollToTopStateAction(navRecyclerView);
        final AlphaSlideAction scrimViewSlideAction = new AlphaSlideAction(scrimView, false);
        final ForegroundSheetTransformSlideAction  foregroundSheetTransformSlideAction = new ForegroundSheetTransformSlideAction(foregroundContainer, getForegroundShapeDrawable(), profileImageView);
        // Add Bottomsheet Behaviour
        behavior.addBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View bottomSheet, int newState) {
                scrimViewVisibilityStateAction.onStateChanged(bottomSheet, newState);
                scrollToTopStateAction.onStateChanged(bottomSheet, newState);
                if(behavior.getState() == BottomSheetBehavior.STATE_EXPANDED) {

                }
                else if(behavior.getState() == BottomSheetBehavior.STATE_HALF_EXPANDED) {

                }
                else if(behavior.getState() == BottomSheetBehavior.STATE_HIDDEN){
                    onBackPressedCallback.setEnabled(false);
                }
            }

            @Override
            public void onSlide(@NonNull View bottomSheet, float slideOffset) {
                scrimViewSlideAction.onSlide(bottomSheet, slideOffset);
                foregroundSheetTransformSlideAction.onSlide(bottomSheet, slideOffset);
            }
        });
        scrimView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                close();
            }
        });
        close();
        profileImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggle();
            }
        });
        final NavigationAdapter adapter = new NavigationAdapter(this);
        navRecyclerView.setAdapter(adapter);
        // Observer
        navigationViewModel.getNavigationList().observe(getViewLifecycleOwner(), new Observer() {
            @Override
            public void onChanged(Object o) {
                adapter.submitList((ArrayList)o);
            }
        });
    }

    private final MaterialShapeDrawable getBackgroundShapeDrawable() {
        Context backgroundContext = backgroundContainer.getContext();
        MaterialShapeDrawable shapeDrawable = new MaterialShapeDrawable(backgroundContext, null, R.attr.bottomSheetStyle, 0);
        TypedValue typedColorValue = new TypedValue();
        backgroundContext.getTheme().resolveAttribute(R.attr.colorPrimaryVariant, typedColorValue, true);
        shapeDrawable.setFillColor(ColorStateList.valueOf(typedColorValue.data));
        shapeDrawable.setElevation(getResources().getDimension(R.dimen.plane_08));
        shapeDrawable.initializeElevationOverlay(backgroundContext);
        return shapeDrawable;
    }

    private final MaterialShapeDrawable getForegroundShapeDrawable() {
        Context foregroundContext = foregroundContainer.getContext();
        MaterialShapeDrawable shapeDrawable = new MaterialShapeDrawable(foregroundContext, null, R.attr.bottomSheetStyle, 0);
        TypedValue typedColorValue = new TypedValue();
        foregroundContext.getTheme().resolveAttribute(R.attr.colorPrimarySurface, typedColorValue, true);
        shapeDrawable.setFillColor(ColorStateList.valueOf(typedColorValue.data));
        shapeDrawable.setElevation(getResources().getDimension(R.dimen.plane_16));
        shapeDrawable.setShadowCompatibilityMode(MaterialShapeDrawable.SHADOW_COMPAT_MODE_NEVER);
        shapeDrawable.initializeElevationOverlay(foregroundContext);
        shapeDrawable.setShapeAppearanceModel(shapeDrawable.getShapeAppearanceModel().toBuilder()
                .setTopEdge(new SemiCircleEdgeCutoutTreatment(getResources().getDimension(R.dimen.grid_1), getResources().getDimension(R.dimen.grid_3),0,getResources().getDimension(R.dimen.navigation_drawer_profile_image_size),0))
                .build());
        return shapeDrawable;
    }

    public final void close() {
        behavior.setState(BottomSheetBehavior.STATE_HIDDEN);
        onBackPressedCallback.setEnabled(false);
    }

    private void closeDrawerOnBackPressed() {
        close();
    }

    public final void open() {
        behavior.setState(BottomSheetBehavior.STATE_HALF_EXPANDED);
        onBackPressedCallback.setEnabled(true);
    }

    private final void expand() {
        behavior.setState(BottomSheetBehavior.STATE_EXPANDED);
        onBackPressedCallback.setEnabled(true);
    }

    public final void outsideToggle() {
        if (this.behavior.getState() == BottomSheetBehavior.STATE_HIDDEN){
            this.open();
        }
        else {
            this.close();
        }
    }

    public final void toggle() {
        if (this.behavior.getState() == BottomSheetBehavior.STATE_HIDDEN) {

        } else if (this.behavior.getState() == BottomSheetBehavior.STATE_HALF_EXPANDED) {
            this.expand();
        }
        else {
            close();
        }
    }

    private final void toggleSandwich() {

    }
}
