package me.pulsz.viewmodels;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import me.pulsz.R;
import me.pulsz.models.NavigationModelItem;
import me.pulsz.models.Taskbox;

public class NavigationViewModel extends AndroidViewModel {
    public static final int HOME_ID = 0;
    public static final int IMPORTANT_ID = 1;
    public static final int COMPLETED_ID = 2;
    public static final int TRASH_ID = 3;
    public static final int DRAFTS_ID = 4;
    private static List navigationMenuItems = new ArrayList();
    private static final MutableLiveData _navigationList = new MutableLiveData();

    public NavigationViewModel(@NonNull Application application) {
        super(application);
        initialize();
    }

    public final LiveData getNavigationList() {
        return (LiveData)_navigationList;
    }

    private void initialize() {
        navigationMenuItems = new ArrayList();
        navigationMenuItems.add(new NavigationModelItem.NavMenuItem(0, R.drawable.ic_twotone_inbox, R.string.menu_item_home, Taskbox.HOME, false));
        navigationMenuItems.add(new NavigationModelItem.NavMenuItem(1, R.drawable.ic_twotone_error, R.string.menu_item_important, Taskbox.IMPORTANT, false));
        navigationMenuItems.add(new NavigationModelItem.NavMenuItem(2, R.drawable.ic_twotone_star, R.string.menu_item_completed, Taskbox.COMPLETED, false));
        navigationMenuItems.add(new NavigationModelItem.NavMenuItem(3, R.drawable.ic_twotone_delete, R.string.menu_item_trash, Taskbox.TRASH, false));
        navigationMenuItems.add(new NavigationModelItem.NavMenuItem(4, R.drawable.ic_twotone_drafts, R.string.menu_item_drafts, Taskbox.DRAFTS, false));
        // Collections
        Collection navMenuItemsCollection = (Collection)navigationMenuItems;
        navMenuItemsCollection.add(new NavigationModelItem.NavDivider("Folders"));
        Collection foldersCollection = (Collection) getAllTaskFolders();
        Iterator iterator = foldersCollection.iterator();
        while (iterator.hasNext()) {
            String folder = (String)iterator.next();
            NavigationModelItem.NavTaskFolder navTaskFolder = new NavigationModelItem.NavTaskFolder(folder);
            navMenuItemsCollection.add(navTaskFolder);
        }
        _navigationList.setValue(navMenuItemsCollection);
    }

    private List getAllTaskFolders() {
        return Arrays.asList(new String[]{ "Personal", "School", "Work", "Other" });
    }
}
