package me.pulsz.actions;

import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

public class ScrollToTopStateAction implements OnStateChangedAction {
    private final RecyclerView recyclerView;

    public ScrollToTopStateAction(RecyclerView recyclerView) {
        this.recyclerView = recyclerView;
    }

    @Override
    public void onStateChanged(View view, int newState) {
        if (newState == 5) {
            this.recyclerView.scrollToPosition(0);
        }
    }
}
