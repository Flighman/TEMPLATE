package me.pulsz.models;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;

public class TaskFolderDiff extends DiffUtil.ItemCallback {
    public static final TaskFolderDiff INSTANCE;

    static {
        INSTANCE = new TaskFolderDiff();
    }

    @Override
    public boolean areItemsTheSame(@NonNull Object oldItem, @NonNull Object newItem) {
        return ((String)oldItem).equals((String) newItem);
    }

    @Override
    public boolean areContentsTheSame(@NonNull Object oldItem, @NonNull Object newItem) {
        return ((String)oldItem).equals((String)newItem);
    }
}
