package me.pulsz.actions;

import android.view.View;

import me.pulsz.utils.AnimationUtils;

public class HalfClockwiseRotateSlideAction implements OnSlideAction {
    private final View view;

    public HalfClockwiseRotateSlideAction(View view) {
        this.view = view;
    }

    @Override
    public void onSlide(View view, float slideOffset) {
        this.view.setRotation(AnimationUtils.normalize(slideOffset, -1.0F, 0.0F, 0.0F, 180.0F));
    }
}
