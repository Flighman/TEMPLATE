package me.pulsz.utils;

import androidx.annotation.ColorInt;
import androidx.annotation.FloatRange;

import com.google.android.material.animation.ArgbEvaluatorCompat;

import kotlin.jvm.internal.Intrinsics;

public final class AnimationUtils {
    public static final float lerp(float startValue, float endValue, @FloatRange(from = 0.0D,fromInclusive = true,to = 1.0D,toInclusive = true) float fraction) {
        return startValue + fraction * (endValue - startValue);
    }

    public static final int lerp(int startValue, int endValue, @FloatRange(from = 0.0D,fromInclusive = true,to = 1.0D,toInclusive = true) float fraction) {
        return Math.round((float)startValue + fraction * (float)(endValue - startValue));
    }

    public static final float lerp(float startValue, float endValue, @FloatRange(from = 0.0D,fromInclusive = true,to = 1.0D,toInclusive = false) float startFraction, @FloatRange(from = 0.0D,fromInclusive = false,to = 1.0D,toInclusive = true) float endFraction, @FloatRange(from = 0.0D,fromInclusive = true,to = 1.0D,toInclusive = true) float fraction) {
        if (fraction < startFraction) {
            return startValue;
        } else {
            return fraction > endFraction ? endValue : lerp(startValue, endValue, (fraction - startFraction) / (endFraction - startFraction));
        }
    }

    public static final int lerp(int startValue, int endValue, @FloatRange(from = 0.0D,fromInclusive = true,to = 1.0D,toInclusive = false) float startFraction, @FloatRange(from = 0.0D,fromInclusive = false,to = 1.0D,toInclusive = true) float endFraction, @FloatRange(from = 0.0D,fromInclusive = true,to = 1.0D,toInclusive = true) float fraction) {
        if (fraction < startFraction) {
            return startValue;
        } else {
            return fraction > endFraction ? endValue : lerp(startValue, endValue, (fraction - startFraction) / (endFraction - startFraction));
        }
    }

    @ColorInt
    public static final int lerpArgb(@ColorInt int startColor, @ColorInt int endColor, @FloatRange(from = 0.0D,fromInclusive = true,to = 1.0D,toInclusive = false) float startFraction, @FloatRange(from = 0.0D,fromInclusive = false,to = 1.0D,toInclusive = true) float endFraction, @FloatRange(from = 0.0D,fromInclusive = true,to = 1.0D,toInclusive = true) float fraction) {
        if (fraction < startFraction) {
            return startColor;
        } else if (fraction > endFraction) {
            return endColor;
        } else {
            Integer var10000 = ArgbEvaluatorCompat.getInstance().evaluate((fraction - startFraction) / (endFraction - startFraction), startColor, endColor);
            Intrinsics.checkExpressionValueIsNotNull(var10000, "ArgbEvaluatorCompat.getI…r,\n        endColor\n    )");
            return var10000;
        }
    }

    public static final float normalize(float value, float inputMin, float inputMax, float outputMin, float outputMax) {
        if (value < inputMin) {
            return outputMin;
        } else {
            return value > inputMax ? outputMax : outputMin * ((float)1 - (value - inputMin) / (inputMax - inputMin)) + outputMax * ((value - inputMin) / (inputMax - inputMin));
        }
    }
}
