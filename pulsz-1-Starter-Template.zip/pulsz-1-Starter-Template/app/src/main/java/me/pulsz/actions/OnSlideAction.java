package me.pulsz.actions;

import android.view.View;

public interface  OnSlideAction {
    void onSlide(View view, float slideOffset);
}
