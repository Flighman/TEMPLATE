package me.pulsz.models;

public enum Taskbox {
    HOME,
    IMPORTANT,
    COMPLETED,
    TRASH,
    DRAFTS
}
