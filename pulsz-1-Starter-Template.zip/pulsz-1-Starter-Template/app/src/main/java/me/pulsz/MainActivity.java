package me.pulsz;

import androidx.annotation.MenuRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.navigation.NavController;
import androidx.navigation.NavDestination;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.google.android.material.bottomappbar.BottomAppBar;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.transition.MaterialElevationScale;

import java.util.Collections;
import java.util.List;

import me.pulsz.actions.HalfClockwiseRotateSlideAction;
import me.pulsz.fragments.BottomNavDrawerFragment;
import me.pulsz.fragments.HomeFragmentDirections;

public class MainActivity extends AppCompatActivity implements NavController.OnDestinationChangedListener {
    private FloatingActionButton fab;
    private NavController navController;
    private BottomNavDrawerFragment bottomNavDrawerFragment;
    private LinearLayout bottomAppBarContentContainer;
    private BottomAppBar bottomAppBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setUpBottomNavigationAndFab();
    }

    private final void setUpBottomNavigationAndFab() {
        setContentView(R.layout.activity_main);
        navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        bottomNavDrawerFragment = this.getBottomNavDrawer();
        bottomAppBarContentContainer = findViewById(R.id.bottom_app_bar_content_container);
        bottomAppBar = findViewById(R.id.bottom_app_bar);
        fab = findViewById(R.id.fab);

        navController.addOnDestinationChangedListener(this);
        navController.navigate(R.id.action_global_homeFragment);
        fab.setHideMotionSpecResource(R.animator.fab_show);
        fab.setHideMotionSpecResource(R.animator.fab_hide);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bottomNavDrawerFragment.close();
                navigateToCompose();
            }
        });
        bottomAppBarContentContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bottomNavDrawerFragment.outsideToggle();
            }
        });
    }

    private final void setBottomAppBarForCompose() {
        this.hideBottomAppBar();
        this.fab.hide();
    }

    private final void setBottomAppBarForHome(@MenuRes int menuRes) {
        this.fab.setImageState(new int[] { -android.R.attr.state_activated}, true);
        bottomAppBar.setVisibility(View.VISIBLE);
        bottomAppBar.replaceMenu(menuRes);
        fab.setContentDescription(getResources().getString(R.string.fab_create_task_content_description));
        bottomAppBar.performShow();
        fab.show();
    }

    private final void navigateToCompose() {
        Fragment currentNavigationFragment = this.getCurrentNavigationFragment();
        if(currentNavigationFragment != null) {
            MaterialElevationScale elevationScale = new MaterialElevationScale(false);
            elevationScale.setDuration(getResources().getInteger(R.integer.share_motion_duration_large));
            currentNavigationFragment.setExitTransition(elevationScale);
            elevationScale = new MaterialElevationScale(true);
            elevationScale.setDuration(getResources().getInteger(R.integer.share_motion_duration_large));
            currentNavigationFragment.setReenterTransition(elevationScale);
        }
        NavigationGraphDirections.ActionGlobalComposeFragment directions = HomeFragmentDirections.actionGlobalComposeFragment();
        navController.navigate(directions);
    }

    @Nullable
    public final Fragment getCurrentNavigationFragment() {
        Fragment currentFragment= this.getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment);
        if(currentFragment != null) {
            FragmentManager childFragmentManager = currentFragment.getChildFragmentManager();
            if(childFragmentManager != null) {
                List fragments = childFragmentManager.getFragments();
                if(fragments != null) {
                    return (Fragment) fragments.get(0);
                }
            }
        }
        return null;
    }

    @MenuRes
    private final int getBottomAppBarMenuForDestination(NavDestination destination) {
        if (destination.getId() == R.id.homeFragment) {
            return R.menu.bottom_app_bar_home_menu;
        }
        else if(destination.getId() == R.id.taskFragment) {
            return R.menu.bottom_app_bar_task_menu;
        }
        else {
            return R.menu.bottom_app_bar_home_menu;
        }
    }

    private final void hideBottomAppBar() {
        this.bottomAppBar.performHide();
    }

    private final BottomNavDrawerFragment getBottomNavDrawer() {
        return (BottomNavDrawerFragment) this.getSupportFragmentManager().findFragmentById(R.id.bottom_nav_drawer);
    }

    @Override
    public void onDestinationChanged(@NonNull NavController controller, @NonNull NavDestination destination, @Nullable Bundle arguments) {
        switch (destination.getId()) {
            case R.id.homeFragment:
                this.setBottomAppBarForHome(this.getBottomAppBarMenuForDestination(destination));
                break;
            case R.id.composeFragment:
                this.setBottomAppBarForCompose();
                break;
        }
    }
}