package me.pulsz.callbacks;

import android.graphics.Canvas;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

public class ReboundingSwipeActionCallback extends ItemTouchHelper.SimpleCallback {
    private static final float swipeReboundingElasticity = 0.8F;
    private static final float trueSwipeThreshold = 0.4F;
    private int currentTargetPosition = -1;
    private boolean currentTargetHasMetThresholdOnce;

    public ReboundingSwipeActionCallback() {
        super(0, ItemTouchHelper.RIGHT);
    }

    public float getSwipeThreshold(RecyclerView.ViewHolder viewHolder){
        return Float.MAX_VALUE;
    }

    public float getSwipeVelocityThreshold(float defaultValue) {
        return Float.MAX_VALUE;
    }

    public float getSwipeEscapeVelocity(float defaultValue) {
        return Float.MAX_VALUE;
    }

    @Override
    public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
        return false;
    }

    @Override
    public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {

    }

    public void clearView(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder) {
        if (this.currentTargetHasMetThresholdOnce && viewHolder instanceof ReboundingSwipeActionCallback.ReboundableViewHolder) {
            this.currentTargetHasMetThresholdOnce = false;
            ((ReboundingSwipeActionCallback.ReboundableViewHolder)viewHolder).onRebounded();
        }
        super.clearView(recyclerView, viewHolder);
    }

    public void onChildDraw(Canvas c, RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, float dX, float dY, int actionState, boolean isCurrentlyActive) {
        if (viewHolder instanceof ReboundingSwipeActionCallback.ReboundableViewHolder) {
            if (this.currentTargetPosition != viewHolder.getAdapterPosition()) {
                this.currentTargetPosition = viewHolder.getAdapterPosition();
                this.currentTargetHasMetThresholdOnce = false;
            }
            View itemView = viewHolder.itemView;
            float currentSwipePercentage = Math.abs(dX) / (float)itemView.getWidth();
            ((ReboundingSwipeActionCallback.ReboundableViewHolder)viewHolder).onReboundOffsetChanged(currentSwipePercentage, trueSwipeThreshold, this.currentTargetHasMetThresholdOnce);
            this.translateReboundingView(itemView, (ReboundingSwipeActionCallback.ReboundableViewHolder)viewHolder, dX);
            if (currentSwipePercentage >= 0.4F && !this.currentTargetHasMetThresholdOnce) {
                this.currentTargetHasMetThresholdOnce = true;
            }
        }
    }

    private final void translateReboundingView(View itemView, ReboundingSwipeActionCallback.ReboundableViewHolder viewHolder, float dX) {
        float swipeDismissDistanceHorizontal = (float)itemView.getWidth() * trueSwipeThreshold;
        double dragTo = (double)((float)1 + dX / swipeDismissDistanceHorizontal);
        double currentDragTo = Math.log(dragTo);
        dragTo = (double)3;
        double newDragTo = Math.log(dragTo);
        double dragFraction = currentDragTo / newDragTo;
        dragTo = dragFraction * (double)swipeDismissDistanceHorizontal * swipeReboundingElasticity;
        viewHolder.getReboundableView().setTranslationX((float)dragTo);
    }

    public interface ReboundableViewHolder {
        View getReboundableView();

        void onReboundOffsetChanged(float currentSwipePercentage, float swipeThreshold, boolean currentTargetHasMetThresholdOnce);

        void onRebounded();
    }
}
