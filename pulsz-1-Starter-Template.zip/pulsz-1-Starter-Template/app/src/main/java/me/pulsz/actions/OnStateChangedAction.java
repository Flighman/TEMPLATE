package me.pulsz.actions;

import android.view.View;


public interface OnStateChangedAction {
    void onStateChanged(View view, int newState);
}
