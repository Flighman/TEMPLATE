package me.pulsz.actions;

import android.annotation.SuppressLint;
import android.view.View;

public final class VisibilityStateAction implements OnStateChangedAction {
    private final View view;
    private final boolean reverse;

    public VisibilityStateAction(View view, boolean reverse) {
        this.view = view;
        this.reverse = reverse;
    }

    @SuppressLint("WrongConstant")
    @Override
    public void onStateChanged(View view, int newState) {
        int stateHiddenVisibility = !this.reverse ? 8 : 0;
        int stateDefaultVisibility = !this.reverse ? 0 : 8;
        switch(newState) {
            case 5:
                this.view.setVisibility(stateHiddenVisibility);
                break;
            default:
                this.view.setVisibility(stateDefaultVisibility);
        }
    }
}
