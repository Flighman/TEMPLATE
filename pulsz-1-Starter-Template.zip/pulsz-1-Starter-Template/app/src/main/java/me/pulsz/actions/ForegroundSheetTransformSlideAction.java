package me.pulsz.actions;

import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.google.android.material.shape.MaterialShapeDrawable;

import me.pulsz.R;
import me.pulsz.utils.AnimationUtils;

public class ForegroundSheetTransformSlideAction implements OnSlideAction {
    private final int foregroundMarginTop;
    private int systemTopInset;
    private final float foregroundZ;
    private final float profileImageOriginalZ;
    private final View foregroundView;
    private final MaterialShapeDrawable foregroundShapeDrawable;
    private final ImageView profileImageView;

    public ForegroundSheetTransformSlideAction(View foregroundView, MaterialShapeDrawable foregroundShapeDrawable, ImageView profileImageView){
        this.foregroundView = foregroundView;
        this.foregroundShapeDrawable = foregroundShapeDrawable;
        this.profileImageView = profileImageView;
        ViewGroup.LayoutParams layoutParams = foregroundView.getLayoutParams();
        if (!(layoutParams  instanceof ViewGroup.MarginLayoutParams)) {
            layoutParams  = null;
        }
        int computedMarginTop = (ViewGroup.MarginLayoutParams)layoutParams != null ? ((ViewGroup.MarginLayoutParams)layoutParams).topMargin : 0;
        this.foregroundMarginTop = computedMarginTop;
        this.foregroundZ = this.foregroundView.getZ();
        this.profileImageOriginalZ = this.profileImageView.getZ();
    }

    @Override
    public void onSlide(View view, float slideOffset) {
        float progress = AnimationUtils.normalize(slideOffset, 0.0F, 0.25F, 1.0F, 0.0F);
        this.profileImageView.setScaleX(progress);
        this.profileImageView.setScaleY(progress);
        this.foregroundShapeDrawable.setInterpolation(progress);
        this.foregroundView.setTranslationY(-((float)1 - progress) * (float)this.foregroundMarginTop);
        float topPaddingProgress = AnimationUtils.normalize(slideOffset, 0.0F, 0.9F, 0.0F, 1.0F);
        int updatedTopPadding = (int)((float)this.getPaddingTop() * topPaddingProgress);
        int foregroundViewPaddingLeft = this.foregroundView.getPaddingLeft();
        int foregroundViewPaddingRight = this.foregroundView.getPaddingRight();
        int foregroundViewPaddingBottom = this.foregroundView.getPaddingBottom();
        this.foregroundView.setPadding(foregroundViewPaddingLeft, updatedTopPadding, foregroundViewPaddingRight, foregroundViewPaddingBottom);
        if (slideOffset > (float)0 && this.foregroundZ <= this.profileImageView.getZ()) {
            this.profileImageView.setZ(this.profileImageOriginalZ);
        } else if (slideOffset <= (float)0 && this.foregroundZ >= this.profileImageView.getZ()) {
            this.profileImageView.setZ(this.foregroundZ + (float)1);
        }
    }

    private final int getPaddingTop() {
        if (this.systemTopInset == 0) {
            Object foregroundViewTag = this.foregroundView.getTag(R.id.tag_system_window_inset_top);
            if (!(foregroundViewTag instanceof Integer)) {
                foregroundViewTag = null;
            }

            this.systemTopInset = (Integer)foregroundViewTag != null ? (Integer)foregroundViewTag : 0;
        }
        return this.systemTopInset;
    }
}
