package me.pulsz.utils;

import com.google.android.material.shape.EdgeTreatment;
import com.google.android.material.shape.ShapePath;

public class SemiCircleEdgeCutoutTreatment extends EdgeTreatment {
    private float cradleDiameter;
    private float cradleRadius;
    private float roundedCornerOffset;
    private float middle;
    private float verticalOffset;
    private float verticalOffsetRatio;
    private float distanceBetweenCenters;
    private float distanceBetweenCentersSquared;
    private float distanceY;
    private float distanceX;
    private float leftRoundedCornerCircleX;
    private float rightRoundedCornerCircleX;
    private float cornerRadiusArcLength;
    private float cutoutArcOffset;
    private float cutoutMargin;
    private float cutoutRoundedCornerRadius;
    private float cutoutVerticalOffset;
    private float cutoutDiameter;
    private float cutoutHorizontalOffset;

    public SemiCircleEdgeCutoutTreatment(float cutoutMargin, float cutoutRoundedCornerRadius, float cutoutVerticalOffset, float cutoutDiameter, float cutoutHorizontalOffset) {
        this.cutoutMargin = cutoutMargin;
        this.cutoutRoundedCornerRadius = cutoutRoundedCornerRadius;
        this.cutoutVerticalOffset = cutoutVerticalOffset;
        this.cutoutDiameter = cutoutDiameter;
        this.cutoutHorizontalOffset = cutoutHorizontalOffset;
    }

    public SemiCircleEdgeCutoutTreatment() {
        this(0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
    }

    public void getEdgePath(float length, float center, float interpolation, ShapePath shapePath) {
        if (this.cutoutDiameter == 0.0F) {
            shapePath.lineTo(length, 0.0F);
        } else {
            this.cradleDiameter = this.cutoutMargin * (float)2 + this.cutoutDiameter;
            this.cradleRadius = this.cradleDiameter / 2.0F;
            this.roundedCornerOffset = interpolation * this.cutoutRoundedCornerRadius;
            this.middle = length / 2.0F + this.cutoutHorizontalOffset;
            this.verticalOffset = interpolation * this.cutoutVerticalOffset + ((float)1 - interpolation) * this.cradleRadius;
            this.verticalOffsetRatio = this.verticalOffset / this.cradleRadius;
            if (this.verticalOffsetRatio >= 1.0F) {
                shapePath.lineTo(length, 0.0F);
            } else {
                this.distanceBetweenCenters = this.cradleRadius + this.roundedCornerOffset;
                this.distanceBetweenCentersSquared = this.distanceBetweenCenters * this.distanceBetweenCenters;
                this.distanceY = this.verticalOffset + this.roundedCornerOffset;
                double computedDistance = (double)(this.distanceBetweenCentersSquared - this.distanceY * this.distanceY);
                double squareRootComputedDistance = Math.sqrt(computedDistance);
                this.distanceX = (float)squareRootComputedDistance;
                this.leftRoundedCornerCircleX = this.middle - this.distanceX;
                this.rightRoundedCornerCircleX = this.middle + this.distanceX;
                computedDistance = (double)(this.distanceX / this.distanceY);
                squareRootComputedDistance = Math.atan(computedDistance);
                this.cornerRadiusArcLength = (float)Math.toDegrees(squareRootComputedDistance);
                this.cutoutArcOffset = (float)90 - this.cornerRadiusArcLength;
                shapePath.lineTo(this.leftRoundedCornerCircleX - this.roundedCornerOffset, 0.0F);
                shapePath.addArc(this.leftRoundedCornerCircleX - this.roundedCornerOffset, 0.0F, this.leftRoundedCornerCircleX + this.roundedCornerOffset, this.roundedCornerOffset * (float)2, (float)270, this.cornerRadiusArcLength);
                shapePath.addArc(this.middle - this.cradleRadius, -this.cradleRadius - this.verticalOffset, this.middle + this.cradleRadius, this.cradleRadius - this.verticalOffset, (float)180 - this.cutoutArcOffset, this.cutoutArcOffset * (float)2 - (float)180);
                shapePath.addArc(this.rightRoundedCornerCircleX - this.roundedCornerOffset, 0.0F, this.rightRoundedCornerCircleX + this.roundedCornerOffset, this.roundedCornerOffset * (float)2, (float)270 - this.cornerRadiusArcLength, this.cornerRadiusArcLength);
                shapePath.lineTo(length, 0.0F);
            }
        }
    }
}
